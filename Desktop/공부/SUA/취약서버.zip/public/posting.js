var express = require('express');
var body_parser = require('body-parser');
app.use(body_parser.urlencoded({extended:false}));
var router = express.Router();
var multipart = require('multipart');
var fs = require('fs');
router.get('/posting', function(req, res, next) {
	res.render('posting');
});
router.post('/posting', function(req, res, next){
	var content = req.body.content;
	console.log(content);
	console.log(req.image);
	console.log('hi');
	var tmp_path = req.files.image.path;
	var target_path = 'images/' + req.files.image.name;
	fs.rename(tpm_path, traget_path, function(err){
		if(err) throw err;
		fs.unlink(tmp_path, function(){
			if(err) throw err;
			res.send('File uploaded to : ' + target_path + '-' +req.files.image.size + 'bytes');
			});
	});
});
module.exports = router;
