var io = require('socket.io').listen(8001);
io.sockets.on('connection', function (socket){
    var room_id;
    socket.on('joinRoom',function(data){
        room_id = data;
        socket.join(room_id); //룸입장
        console.log('JOIN ROOM LIST', io.sockets.adapter.rooms);
    });
    socket.on('leaveRoom',function(){
        socket.leave(room_id);//룸퇴장
        console.log('OUT ROOM LIST', io.sockets.adapter.rooms);
    });
    socket.on('sendMsg',function(data){
        io.sockets.in(room_id).emit('msgAlert',data);//자신포함 전체 룸안의 유저
        //socket.broadcast.to(room_id).emit('msgAlert',data); //자신 제외 룸안의 유저
        //socket.in(room_id).emit('msgAlert',data);  //broadcast 동일하게 가능 자신 제외 룸안의 유저
        //io.of('namespace').in(room_id).emit('msgAlert', data) //of 지정된 name space의 유저의 룸
    });
    socket.on('disconnect', function(){
        console.log('NOT USER DISCONNECT : ', socket.id);
        console.log('ROOM LIST', io.sockets.adapter.rooms);
    });
    /*
     * 룸리스트 콘솔로그
     * socket.io 1.x 에서 io.sockets.manager.rooms => io.sockets.adapter.rooms
     * ROOM LIST { qNADgg3CCxESDLm5AAAA: [ qNADgg3CCxESDLm5AAAA: true ],
          test_room:
           [ qNADgg3CCxESDLm5AAAA: true,
             '0rCX3v4pufWvQ6uwAAAB': true,
             'iH0wJHGh-qKPRd2RAAAC': true ],
          '0rCX3v4pufWvQ6uwAAAB': [ '0rCX3v4pufWvQ6uwAAAB': true ],
          'iH0wJHGh-qKPRd2RAAAC': [ 'iH0wJHGh-qKPRd2RAAAC': true ] }
     */
});
