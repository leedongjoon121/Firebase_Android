

module.exports = function(app)
{
  var fs = require('fs');
  <!--MySQL 연동 및 데이터베이스 커넥션 풀 생성-->
  var mysql = require('mysql');
  var pool      =    mysql.createPool({
      connectionLimit : 10, //important
      host     : 'localhost',
      user     : 'root',
      password : '1234',
      database : 'cnsdata',
      debug    :  false
  });
  <!--NAVER SMTP 프로토콜 사용을 위함-->
  var email = require("emailjs");
  var server = email.server.connect({
      user: "leeseoju1114@naver.com",
      password: "dltmdwn!2#",
      host: "smtp.naver.com",
      port: 465,
      ssl: true
  });
  <!-- EJS 모듈을 사용-->
  var ejs = require("ejs");
  <!-- POST 요청을 처리하기 위한 body-parser-->
  var body_parser = require('body-parser');
  app.use(body_parser.urlencoded({extended:false}));
  <!--세션 관리를 위한 플러그인 session-->
  var session = require('express-session');
  app.use(session({
    secret:'qojd0qwdmadwdAvoBspzmxcB2421Akmqpod',
    resave:false,
    saveUninitialized:true
  }));
  <!--앱의 jade 플러그인 설정-->
  app.locals.pretty = true;
  app.set('view engine','jade');
  app.set('views','./views');
  <!-- 앱의 정적 컨텐츠 경로 설정.-->
  app.use(express.static('public'));
  <!-- 요청에 따라 json 타입을 리턴함(select문 이용) -->

  function handleReadDataBase(res,req,query,successfunc)
  {
    console.log("처리할 sql문 :"+query);
    pool.getConnection(function(err,connection){
          if (err) {
            console.log("데이터베이스 커넥션 풀 생성 실패.");
            res.json({"code" : 100, "status" : "Error in connection database"});
            return;
          }

          console.log('연결된 커넥션 풀 ID :  ' + connection.threadId);
          connection.query(query,function(err,rows){
              connection.release();

              if(rows=="")
              {
                console.log("해당 쿼리 내용 없음!");
                successfunc(rows,100);
                return;
              }
              if(!err) {
                console.log("처리된 값들 :" + rows);
                successfunc(rows,200);
                  <!--json 데이터 반환함-->
              }
          });

          connection.on('error', function(err) {
                res.json({"code" : 100, "status" : "Error in connection database"});
                return;
          });
    });
  }
  <!-- 요청에 따라 insert, delete문을 실행-->
  function handleWriteDataBase(res,req,query,json,successFunc)
  {
    pool.getConnection(function(err,connection){
          if (err) {
            console.log("데이터베이스 커넥션 풀 생성 실패.");
            res.json({"code" : 100, "status" : "Error in connection database"});
            return;
          }

          console.log('연결된 커넥션 풀 ID :  ' + connection.threadId);
          var qu = connection.query(query,json,function(err,result){
              connection.release();

              if(!err) {
                  <!--json 데이터 반환함-->
                  successFunc(200);
              }
              else{
                  successFunc(500);
              }
          });
          connection.on('error', function(err) {
                res.json({"code" : 100, "status" : "Error in connection database"});
                return;
          });
    });
  }

  <!-- / 라우터로 요칭이 왔을 시에-->
  app.get('/', function (req, res) {
    console.log('/ 라우터로 접속시도');
    <!-- 기본 인덱스 홈페이지를 보여줘야함.-->
    fs.readFile('./public/index.html','utf8',function(err,data){
      <!-- 비동기 방식으로 파일을 읽으며 index.html 홈페이지를 보내준다.-->
      console.log("/ 라우터 파일읽기가 완료되었습니다");
      res.send(data);
      <!-- 클라이언트에게 index.html 홈페이지 전달-->
    });
  });
  <!--메인 페이지에 post를 통한 로그인 요청이 도착-->
  app.post('/',function(req,res)
  {
    <!-- 클라이언트로 부터 로그인 요청이 도착-->
    console.log("로그인 요청이 들어왔습니다.  아이디: "+req.body.ID+" 비밀번호: "+req.body.PW+" 타입: "+req.body.login_type);
    if(req.session.login =="true")
    {
      <!-- 이미 로그인이 되어있는 클라이언트라면 해당 세션을 지워버리고 다시 등록한다. -->
      req.session.destroy(function(){
          req.session;
      });
    }
    if(req.body.login_type=="normal")
    {
      console.log("일반 계정으로 로그인 신청");
      var sql = "select user_name,EMAIL,accountType,authorization from userSJ where ID='"+req.body.ID+"' AND PW='"+req.body.PW+"' AND accountType='"+req.body.login_type+"';";
      handleReadDataBase(res,req,sql,function(rows,code){
        <!--로그인 요청이 완료되었다면 세션에 아이디를 저장한다-->

        if(code==200)
        {
          if(rows[0].authorization=="true")
          {
            res.json({"code":200,"status":"정보에 대한 값들","rows":rows});
          req.session.login="true";
          req.session.login_id=req.body.ID;
          req.session.page = 5;
          req.session.name = rows[0].user_name;
          req.session.type="normal";
          req.session.save();
            console.log("세션 등록완료");
          }
          else {
            res.json({"code":150,"status":"이메일 인증을 받지 않았습니다."});
          }
        console.log("세션 등록완료");
        }
        else {
            res.json({"code":100,"status":"로그인 오류"});
        }
      });
    }
    else if(req.body.type=="facebook")
    {
      console.log("페이스북으로 로그인 요청");
      <!-- 페이스북으로 로그인 요청이 왔을 경우에는, 데이터베이스로부터 해당 페이스북 계정이 데이터베이스에 등록됬는지 확인해야함..-->
      var sql = "select user_name,accountType from userSJ where ID='"+req.body.id+"' AND accountType='"+req.body.type+"';";
      handleReadDataBase(res,req,sql,function(rows,code){
        <!--로그인 요청이 완료되었다면 세션에 아이디를 저장한다-->
        if(code==200)
        {
          res.json({"code":200,"status":"정보에 대한 값들","rows":rows});
          req.session.login="true";
          req.session.login_id=req.body.id;
          req.session.page = 5;
          req.session.name = rows[0].user_name;
          req.session.type="facebook";
          req.session.save();
            console.log("세션 등록완료");
        }
        else {
  res.json({"code":code,"status":"로그인실패"});
        }
      });
    }
    else {

    }

  });
  <!-- 메인페이지를 요청 했을 경우-->
  app.get('/main',function(req,res){
    if(req.session.login=="true")
    {
      //로그인 중이여야함
      fs.readFile('./public/main.html','utf8',function(err,data){
          if(err)
          {
            res.json(err);
          }
          else {
            res.send(data);
          }
      });
    }
    else
    {
      res.json({"code":100,"status":"로그인 중이 아닙니다."});
    }
  });
  <!-- 로그아웃을 요청 했을 경우-->
  app.post('/logout',function(req,res){
    var type = req.session.type;
    if(req.session.login=="true")
    {
      req.session.destroy(function(){
        res.json({"code":200,"status":"로그아웃에 성공.","type":type});
          req.session;
      });
    }
    else{
      res.json({"code":100,"status":"로그인 중이 아닙니다."});
    }
  });
  <!--여러 페이지에서 세션에 저장된 로그인 값을 확인, 로그인이 된 상태인지 확인한다
  -->
  app.post('/session',function(req,res){
    console.log("세션확인");
    if(req.session.login=="true")
      {
        res.send({"code":200,"status":"로그인 중입니다.","data":req.session.login_id});
      }
      else {
        res.send({"code":100,"status":"로그인 중이 아닙니다."});
      }
  });
  <!-- 이메일 인증-->
  app.post('/authorization',function(req,res){
    console.log("이메일 인증요청:"+req.body.authorization);
    var query = "update userSJ set authorization='true' where ID=? AND authorization_id=?";
    var json = [req.body.id,req.body.authorization];
    handleWriteDataBase(res,req,query,json,function(code){
      if(code==200)
      {
        pool.getConnection(function(err,connection){
          var query="select * from userSJ where ID='"+req.body.id+"' AND authorization_id='"+req.body.authorization+"''";
              if (err) {
                console.log("데이터베이스 커넥션 풀 생성 실패.");
                res.json({"code" : 100, "status" : "Error in connection database"});
                return;
              }

              console.log('연결된 커넥션 풀 ID :  ' + connection.threadId);
              connection.query(query,function(err,rows){
                  connection.release();

                  if(rows=="")
                  {
                    console.log("알수없는 오류발생");
                    res.json({"code":100,"status":"알 수 없는 오류"});
                    return;
                  }
                  else{
                      res.send("<script type='text/javascript'>alert('인증완료 되었습니다.');location.href='http://127.0.0.1:65017/';</script>");
                      var friendlist = "create table "+req.body.id+"Friendlist ( ID varchar(50), date varchar(50));";
                      pool.getConnection(function(err,connection){
                            if (err) {
                              console.log("데이터베이스 커넥션 풀 생성 실패.");
                              res.json({"code" : 100, "status" : "Error in connection database"});
                              return;
                            }

                            console.log('연결된 커넥션 풀 ID :  ' + connection.threadId);
                            var qu = connection.query(friendlist,function(err,result){
                                connection.release();
                                var sql = "insert into "+req.body.id+"Friendlist set id='"+req.body.id+"'";
                                connection.query(sql);
                                sql ="create table "+req.body.id+"Follower ( ID varchar(50) , date varchar(50));";
                                connection.query(sql);
                                sql ="create table "+req.body.id+"Scwrap ( board_no INTEGER);";
                                connection.query(sql);
                            });
                            connection.on('error', function(err) {
                                  res.json({"code" : 100, "status" : "Error in connection database"});
                                  return;
                            });
                      });

                  }
                  if(!err) {
                    console.log("처리된 값들 :" + rows);
                      <!--json 데이터 반환함-->

                  }
              });
              connection.on('error', function(err) {
                    res.json({"code" : 100, "status" : "Error in connection database"});
                    return;
              });
        });

      }
      else {
        res.send("<script type='text/javascript'>alert('인증실패 되었습니다.');location.href='http://127.0.0.1:65017/';</script>");
      }

    });
  });
  <!-- 회원가입 요청-->
  app.post('/signup',function(req,res){
    console.log("회원가입요청");
      console.log("회원가입 요청 :ID :"+req.body.id+" EMAIL : "+req.body.email+" PW : "+req.body.pw+" NAME : "+req.body.user_name+" DATE: "+req.body.date);
    if(req.body.type=="normal")
    {
        console.log("일반용으로 회원가입요청");
        var query = "insert into userSJ set ?";
        var authorization_code = generateAuthorCode();
        var requestID = req.body.id;
        var json={ID:req.body.id,accountType: req.body.type,PW:req.body.pw,EMAIL:req.body.email,user_name:req.body.user_name,authorization:"false",date:req.body.date,authorization_id:authorization_code};

        handleWriteDataBase(res,req,query,json,function(code){
          if(code==200)
          {
            console.log("회원가입 승인완료.");
            res.json({"code" : 200, "status" : "회원가입이 완료되었습니다.","email" : req.body.email});
            var headers = {
              text: "전송될 내용<p></p>",
              from: "leeseoju1114@naver.com",
              to: req.body.email,
              subject: "Computer Science Network 이메일 인증입니다.",
              };

              // create the message
              var message = email.message.create(headers);

              // attach an alternative html email for those with advanced email clients
              message.attach_alternative("<html><form method='post' action='http://127.0.0.1:65017/authorization'><input type='hidden' name='id' value='"+requestID+"'/><input type='hidden' name='authorization' value = '"+authorization_code+"'><button  type='submit'>이메일 인증하기</button></form></html>");
            server.send(message, function (err, message) {
              if(!err)
                console.log("이메일 인증 전송");
              else {
                console.log("이메일 인증 전송 실패");
              }
            });

          }
          else if(code==500)
          {
            //insert문 오류
            console.log("insert 문 오류!!");
            pool.getConnection(function(err,connection){
              var query="select * from userSJ where ID='"+req.body.id+"'";
                  if (err) {
                    console.log("데이터베이스 커넥션 풀 생성 실패.");
                    res.json({"code" : 100, "status" : "Error in connection database"});
                    return;
                  }

                  console.log('연결된 커넥션 풀 ID :  ' + connection.threadId);
                  connection.query(query,function(err,rows){
                      connection.release();

                      if(rows=="")
                      {
                        console.log("알수없는 오류발생");
                        res.json({"code":100,"status":"알 수 없는 오류"});
                        return;
                      }
                      if(!err) {
                        console.log("처리된 값들 :" + rows);
                        res.json({"code":300,"status":"이미 가입된 아이디입니다."});
                          <!--json 데이터 반환함-->
                      }
                  });

                  connection.on('error', function(err) {
                        res.json({"code" : 100, "status" : "Error in connection database"});
                        return;
                  });
            });
          }
        });
          //res.send(200,'success');
    }
    else if(req.body.type=="facebook")
    {
        console.log("페이스북으로 회원가입 요청");
        var query = "insert into userSJ set ?";
        var json={ID:req.body.id,accountType: req.body.type,PW:req.body.pw,EMAIL:req.body.email,user_name:req.body.user_name,authorization:"false",date:req.body.date,authorization_id:0};

        handleWriteDataBase(res,req,query,json,function(code){
          if(code==200)
          {
            console.log("회원가입 승인완료.");
            res.json({"code" : 200, "status" : "회원가입이 완료되었습니다."});
            var friendlist = "create table "+req.body.id+"Friendlist ( ID varchar(50), date varchar(50));";
            pool.getConnection(function(err,connection){
                  if (err) {
                    console.log("데이터베이스 커넥션 풀 생성 실패.");
                    res.json({"code" : 100, "status" : "Error in connection database"});
                    return;
                  }

                  console.log('연결된 커넥션 풀 ID :  ' + connection.threadId);
                  var qu = connection.query(friendlist,function(err,result){
                      var sql = "insert into "+req.body.id+"Friendlist set id='"+req.body.id+"'";
                      connection.query(sql,function(err,result){});
                      sql ="create table "+req.body.id+"Follower ( ID varchar(50) , date varchar(50));";
                      connection.query(sql,function(err,result){});
                      sql ="create table "+req.body.id+"Scrap ( board_no INTEGER);";
                      connection.query(sql,function(err,result){});
                      connection.end();
                  });
                  connection.on('error', function(err) {
                        res.json({"code" : 100, "status" : "Error in connection database"});
                        return;
                  });
            });
          }
          else if(code==500)
          {
            //insert문 오류
            console.log("insert 문 오류!!");
            pool.getConnection(function(err,connection){
              var query="select * from userSJ where ID='"+req.body.id+"'";
                  if (err) {
                    console.log("데이터베이스 커넥션 풀 생성 실패.");
                    res.json({"code" : 100, "status" : "Error in connection database"});
                    return;
                  }

                  console.log('연결된 커넥션 풀 ID :  ' + connection.threadId);
                  connection.query(query,function(err,rows){
                      connection.release();

                      if(rows=="")
                      {
                        console.log("알수없는 오류발생");
                        res.json({"code":100,"status":"알 수 없는 오류"});
                        return;
                      }
                      if(!err) {
                        console.log("처리된 값들 :" + rows);
                        res.json({"code":300,"status":"이미 가입된 아이디입니다."});
                          <!--json 데이터 반환함-->
                      }
                  });

                  connection.on('error', function(err) {
                        res.json({"code" : 100, "status" : "Error in connection database"});
                        return;
                  });
            });
          }
        });
    }
  });
  <!-- 글쓰기 요청-->
  app.post('/write',function(req,res){
    //글쓰기
  //  console.log("ㅇㅇ");
    var sql = "insert into board set ?";
    var board = {
      date : new Date(),
      id : req.session.login_id,
      text : req.body.text,
      code : req.body.code,
      name : req.session.name,
      likeCnt: 0,
      replyCnt:0
    };
    console.log(req.body.text);
    handleWriteDataBase(req,res,sql,board,function(code){
  console.log(code);
        if(code==200)
        {
          res.json({"code":200,"status":"글 올라감."});
        }else {
          res.json({"code":500,"status":"에러"});
        }
    });
  });
  <!-- 댓글 조회-->
  app.post('/reply',function(req,res){
    if(req.session.login=="true")
    {
      //세션에 로그인이 되어있어야 한다.
      fs.readFile('./public/ejs/reply.ejs',"utf8",function(err,data){

        pool.getConnection(function(err,connection){
          if(!err)
          {
            var board_no = req.body.board_no;
            var sql = "select * from replyzone where board_no="+board_no;//해당 게시글의 댓글정보 요청
            connection.query(sql,function(err,rows){
              if(err)
              {
                console.log(err);
                return;
              }
              if(rows.length>=1)
              {
                //결과값이 있을 경우.
                console.log("댓글확인요청");
                var replylist = new Array(); //댓글 리스트를 저장.
                for(var i=0; i <rows.length;i++)
                {
                  replylist.push({
                    id:rows[i].ID,
                    name:rows[i].name,
                    date:rows[i].date,
                    text:rows[i].text
                  });
                }
                var reply = {
                  replycnt : rows.length,
                  list : replylist
                }
                console.log(reply);
                  res.send(ejs.render(data,reply));
              }
            });

          }
          else
          {

          }
        });

      });
    }
  });
  <!-- 댓글 달기-->
  app.post('/writeReply',function(req,res){
    if(req.session.login=="true")
    {
      //로그인 상태 확인.
      var data = {
        ID : req.session.login_id,
        name : req.session.name,
        date : new Date(),
        text : req.body.text,
        likeCnt :0,
        board_no : req.body.board_no
      };
      console.log(data);
      var sql = "insert into replyzone set ?";
      handleWriteDataBase(req,res,sql,data,function(code){
        if(code==200)
        {
          sql = "update board set replyCnt= replyCnt+1 where board_no ="+req.body.board_no;
          pool.getConnection(function(err,connection){
            connection.query(sql,function(err,rows){
              if(!err)
              {
                res.json({"code":200,"status":"글 올라감."});
                console.log("증가함");
              }
              else
              {console.log("댓글증가에러");}
            });
          });
        }else {
          res.json({"code":500,"status":"에러"});
        }
      });
    }
  });

  <!-- 좋아요 누르기-->
  app.post('/like',function(req,res){
    if(req.session.login=="true")
    {
      pool.getConnection(function(err,connection){
        var sql = "select * from likezone where ID='"+req.session.login_id+"' AND board_no="+req.body.board_no;
        connection.query(sql,function(err,rows){
          if(err)
          {
            res.json({"code":300,"status":"알 수 없는 오류"});
          }
          else {
            if(rows.length==0)
            {
              sql = "insert into likezone set ?";
              var data = {
                ID : req.session.login_id,
                board_no : req.body.board_no
              };
              handleWriteDataBase(req,res,sql,data,function(code){
                if(code==200)
                {
                  sql = "update board set likeCnt=likeCnt+1 where board_no="+req.body.board_no;
                  connection.query(sql,function(err,rows){
                    if(!err)
                    {
                            res.json({"code":200,"status":"좋아요 처리완료"});
                    }
                  });
                }
              });
            }
            else
            {
              res.json({"code":400,"status":"좋아요 이미 누름."});
            }
          }
        });
      });
    }
  });
  <!-- 타임라인 -->
  app.post('/timeline',function(req,res){

  });
  <!-- 게시글 보기 요청-->
  app.post('/board',function(req,res){
    if(req.session.login=="true")
    {
      fs.readFile('./public/ejs/board.ejs',"utf8",function(err,data){
        if(err){
          console.log(err);
          console.log("에러")
        }else{
          var id = req.session.login_id;
          var sql = "select * from board where id IN (select id from "+id+"Friendlist)  order by board_no desc;";
          handleReadDataBase(req,res,sql,function(rows,code){
            if(rows.length>=1)
            {
                var board_array = new Array();
                var myrows = rows;
                console.log(rows.length);

                  for(var k=0;k<rows.length;k++)
                  {
                    board_array.push({
                      board_no : rows[k].board_no,
                      img_url:"user.PNG",
                      name:rows[k].name,
                      date:rows[k].date,
                      text:rows[k].text,
                      codeground:  rows[k].code,
                      codeline: rows[k].codeline,
                      likeCnt:rows[k].likeCnt,
                      replyCnt:rows[k].replyCnt
                    });
                  }

                  var jsonData = {
                    board_cnt: board_array.length,
                    board:board_array
                  };
                                console.log("전송");
                                res.send(ejs.render(data,jsonData));
               }
          });
          }
      });
    }
    else {

    }
  });
  function generateAuthorCode()
  {
    return Math.random();
  }

};
