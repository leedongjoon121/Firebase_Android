var express = require('express');

var app = express();
<!-- 파일 시스템 불러오기 -->
var fs = require('fs');
<!-- 시크릿 코드 삽입-->
var secret = "aAbBcCdDeEfFgGhH";
<!--MySQL 연동 및 데이터베이스 커넥션 풀 생성-->
var mysql = require('mysql');
var pool      =    mysql.createPool({
    connectionLimit : 30, //important
    host     : 'localhost',
    user     : 'root',
    password : '1234',
    database : 'cnsdata',
    debug    :  false
});
<!--NAVER SMTP 프로토콜 사용을 위함-->
var email = require("emailjs");
var server = email.server.connect({
    user: "leeseoju1114@naver.com",
    password: "dltmdwn!2#",
    host: "smtp.naver.com",
    port: 465,
    ssl: true
});
<!-- 가천대학교 html 가져오기-->
var cheerio = require('cheerio');
var request = require('request');
var pageNum = 0;
var gachonUrl = 'http://www.gachon.ac.kr/major/bbs.jsp?pageNum='+pageNum+'&pageSize=10&boardType_seq=159&approve=&secret=&answer=&branch=&searchopt=&searchword=';
<!-- EJS 모듈을 사용-->
var ejs = require("ejs");
<!-- POST 요청을 처리하기 위한 body-parser-->
var body_parser = require('body-parser');
app.use(body_parser.urlencoded({extended:false}));
<!--세션 관리를 위한 플러그인 session-->
var session = require('express-session');
app.use(session({
  secret:'qojd0qwdmadwdAvoBspzmxcB2421Akmqpod',
  resave:false,
  saveUninitialized:true
}));
<!--앱의 jade 플러그인 설정-->
app.locals.pretty = true;
app.set('view engine','jade');
app.set('views','./views');
<!-- 앱의 정적 컨텐츠 경로 설정.-->
app.use(express.static('public'));
<!-- 요청에 따라 json 타입을 리턴함(select문 이용) -->
function handleReadDataBase(res,req,query,successfunc)
{
  console.log("처리할 sql문 :"+query);
  pool.getConnection(function(err,connection){
        if (err) {
          console.log("데이터베이스 커넥션 풀 생성 실패.");
          res.json({"code" : 100, "status" : "Error in connection database"});
          return;
        }

        console.log('연결된 커넥션 풀 ID :  ' + connection.threadId);
        connection.query(query,function(err,rows){
            connection.release();

            if(rows=="")
            {
              console.log("해당 쿼리 내용 없음!");
              successfunc(rows,100);
              return;
            }
            if(!err) {
              console.log("처리된 값들 :" + rows);
              successfunc(rows,200);
                <!--json 데이터 반환함-->
            }
        });

        connection.on('error', function(err) {
              res.json({"code" : 100, "status" : "Error in connection database"});
              return;
        });
  });
}
<!-- 요청에 따라 insert, delete문을 실행-->
function handleWriteDataBase(res,req,query,json,successFunc)
{
  pool.getConnection(function(err,connection){
        if (err) {
          console.log("데이터베이스 커넥션 풀 생성 실패.");
          res.json({"code" : 100, "status" : "Error in connection database"});
          return;
        }

        console.log('연결된 커넥션 풀 ID :  ' + connection.threadId);
        var qu = connection.query(query,json,function(err,result){
            connection.release();

            if(!err) {
                <!--json 데이터 반환함-->
                successFunc(200);
            }
            else{
                successFunc(500);
            }
        });
        connection.on('error', function(err) {
              res.json({"code" : 100, "status" : "Error in connection database"});
              return;
        });
  });
}

<!-- / 라우터로 요칭이 왔을 시에-->
app.get('/', function (req, res) {
  console.log('/ 라우터로 접속시도');
  <!-- 기본 인덱스 홈페이지를 보여줘야함.-->
  fs.readFile('index.html','utf8',function(err,data){
    <!-- 비동기 방식으로 파일을 읽으며 index.html 홈페이지를 보내준다.-->
    console.log("/ 라우터 파일읽기가 완료되었습니다");
    res.send(data);
    <!-- 클라이언트에게 index.html 홈페이지 전달-->
  });
});
<!--메인 페이지에 post를 통한 로그인 요청이 도착-->
app.post('/',function(req,res)
{
  <!-- 클라이언트로 부터 로그인 요청이 도착-->
  console.log("로그인 요청이 들어왔습니다.  아이디: "+req.body.ID+" 비밀번호: "+req.body.PW+" 타입: "+req.body.login_type);
  if(req.session.login =="true")
  {
    <!-- 이미 로그인이 되어있는 클라이언트라면 해당 세션을 지워버리고 다시 등록한다. -->
    req.session.destroy(function(){
        req.session;
    });
  }
  if(req.body.login_type=="normal")
  {
    console.log("일반 계정으로 로그인 신청");
    var sql = "select user_name,EMAIL,accountType,authorization from user where ID='"+req.body.ID+"' AND PW='"+req.body.PW+"' AND accountType='"+req.body.login_type+"';";
    handleReadDataBase(res,req,sql,function(rows,code){
      <!--로그인 요청이 완료되었다면 세션에 아이디를 저장한다-->

      if(code==200)
      {
        if(rows[0].authorization=="true")
        {
          res.json({"code":200,"status":"정보에 대한 값들","rows":rows});
        req.session.login="true";
        req.session.login_id=req.body.ID;
        req.session.page = 5;
        req.session.name = rows[0].user_name;
        req.session.type="normal";
        req.session.save();
          console.log("세션 등록완료");
        }
        else {
          res.json({"code":150,"status":"이메일 인증을 받지 않았습니다."});
        }
      console.log("세션 등록완료");
      }
      else {
          res.json({"code":100,"status":"로그인 오류"});
      }
    });
  }
  else if(req.body.type=="facebook")
  {
    console.log("페이스북으로 로그인 요청");
    <!-- 페이스북으로 로그인 요청이 왔을 경우에는, 데이터베이스로부터 해당 페이스북 계정이 데이터베이스에 등록됬는지 확인해야함..-->
    var sql = "select user_name,accountType from user where ID='"+req.body.id+"' AND accountType='"+req.body.type+"';";
    handleReadDataBase(res,req,sql,function(rows,code){
      <!--로그인 요청이 완료되었다면 세션에 아이디를 저장한다-->
      if(code==200)
      {
        res.json({"code":200,"status":"정보에 대한 값들","rows":rows});
        req.session.login="true";
        req.session.login_id=req.body.id;
        req.session.page = 5;
        req.session.name = rows[0].user_name;
        req.session.type="facebook";
        req.session.save();
          console.log("세션 등록완료");
      }
      else {
res.json({"code":code,"status":"로그인실패"});
      }
    });
  }
  else {

  }

});
<!-- 메인페이지를 요청 했을 경우-->
app.get('/main',function(req,res){
  if(req.session.login=="true")
  {
    //로그인 중이여야함
    fs.readFile('./public/main.html','utf8',function(err,data){
        if(err)
        {
          res.json(err);
        }
        else {
          res.send(data);
        }
    });
  }
  else
  {
    res.json({"code":100,"status":"로그인 중이 아닙니다."});
  }
});
<!-- 로그아웃을 요청 했을 경우-->
app.post('/logout',function(req,res){
  var type = req.session.type;
  if(req.session.login=="true")
  {
    req.session.destroy(function(){
      res.json({"code":200,"status":"로그아웃에 성공.","type":type});
        req.session;
    });
  }
  else{
    res.json({"code":100,"status":"로그인 중이 아닙니다."});
  }
});
<!--여러 페이지에서 세션에 저장된 로그인 값을 확인, 로그인이 된 상태인지 확인한다
-->
app.post('/session',function(req,res){
  console.log("세션확인");
  if(req.session.login=="true")
    {
      res.send({"code":200,"status":"로그인 중입니다.","id":req.session.login_id,"name":req.session.name});
    }
    else {
      res.send({"code":100,"status":"로그인 중이 아닙니다."});
    }
});
<!-- 이메일 인증-->
app.post('/authorization',function(req,res){
  console.log("이메일 인증요청:"+req.body.authorization);
  var query = "update user set authorization='true' where ID=? AND authorization_id=?";
  var json = [req.body.id,req.body.authorization];
  handleWriteDataBase(res,req,query,json,function(code){
    if(code==200)
    {
      pool.getConnection(function(err,connection){
        var query="select * from user where ID='"+req.body.id+"' AND authorization_id='"+req.body.authorization+"''";
            if (err) {
              console.log("데이터베이스 커넥션 풀 생성 실패.");
              res.json({"code" : 100, "status" : "Error in connection database"});
              return;
            }

            console.log('연결된 커넥션 풀 ID :  ' + connection.threadId);
            connection.query(query,function(err,rows){
                connection.release();

                if(rows=="")
                {
                  console.log("알수없는 오류발생");
                  res.json({"code":100,"status":"알 수 없는 오류"});
                  return;
                }
                else{
                    res.send("<script type='text/javascript'>alert('인증완료 되었습니다.');location.href='http://localhost:65017/';</script>");
                    var friendlist = "create table "+req.body.id+"Friendlist ( ID varchar(50), date varchar(50));";
                }
                if(!err) {
                  console.log("처리된 값들 :" + rows);
                    <!--json 데이터 반환함-->

                }
            });
            connection.on('error', function(err) {
                  res.json({"code" : 100, "status" : "Error in connection database"});
                  return;
            });
      });

    }
    else {
      res.send("<script type='text/javascript'>alert('인증실패 되었습니다.');location.href='http://localhost:65017/';</script>");
    }

  });
});
<!-- 회원가입 요청-->
app.post('/signup',function(req,res){
  console.log("회원가입요청");
    console.log("회원가입 요청 :ID :"+req.body.id+" EMAIL : "+req.body.email+" PW : "+req.body.pw+" NAME : "+req.body.user_name+" DATE: "+req.body.date);
  if(req.body.type=="normal")
  {
      console.log("일반용으로 회원가입요청");
      var query = "insert into user set ?";
      var authorization_code = generateAuthorCode();
      var requestID = req.body.id;
      var json={ID:req.body.id,accountType: req.body.type,PW:req.body.pw,EMAIL:req.body.email,user_name:req.body.user_name,authorization:"false",date:req.body.date,authorization_id:authorization_code};

      handleWriteDataBase(res,req,query,json,function(code){
        if(code==200)
        {
          console.log("회원가입 승인완료.");
          res.json({"code" : 200, "status" : "회원가입이 완료되었습니다.","email" : req.body.email});
          var headers = {
            text: "전송될 내용<p></p>",
            from: "leeseoju1114@naver.com",
            to: req.body.email,
            subject: "Computer Science Network 이메일 인증입니다.",
            };

            // create the message
            var message = email.message.create(headers);

            // attach an alternative html email for those with advanced email clients
            message.attach_alternative("<html><form method='post' action='http://localhost:65017/authorization'><input type='hidden' name='id' value='"+requestID+"'/><input type='hidden' name='authorization' value = '"+authorization_code+"'><button  type='submit'>이메일 인증하기</button></form></html>");
          server.send(message, function (err, message) {
            if(!err)
              console.log("이메일 인증 전송");
            else {
              console.log("이메일 인증 전송 실패");
            }
          });

        }
        else if(code==500)
        {
          //insert문 오류
          console.log("insert 문 오류!!");
          pool.getConnection(function(err,connection){
            var query="select * from user where ID='"+req.body.id+"'";
                if (err) {
                  console.log("데이터베이스 커넥션 풀 생성 실패.");
                  res.json({"code" : 100, "status" : "Error in connection database"});
                  return;
                }

                console.log('연결된 커넥션 풀 ID :  ' + connection.threadId);
                connection.query(query,function(err,rows){
                    connection.release();

                    if(rows=="")
                    {
                      console.log("알수없는 오류발생");
                      res.json({"code":100,"status":"알 수 없는 오류"});
                      return;
                    }
                    if(!err) {
                      console.log("처리된 값들 :" + rows);
                      res.json({"code":300,"status":"이미 가입된 아이디입니다."});
                        <!--json 데이터 반환함-->
                    }
                });

                connection.on('error', function(err) {
                      res.json({"code" : 100, "status" : "Error in connection database"});
                      return;
                });
          });
        }
      });
        //res.send(200,'success');
  }
  else if(req.body.type=="facebook")
  {
      console.log("페이스북으로 회원가입 요청");
      var query = "insert into user set ?";
      var json={ID:req.body.id,accountType: req.body.type,PW:req.body.pw,EMAIL:req.body.email,user_name:req.body.user_name,authorization:"false",date:req.body.date,authorization_id:0};

      handleWriteDataBase(res,req,query,json,function(code){
        if(code==200)
        {
          console.log("회원가입 승인완료.");
          res.json({"code" : 200, "status" : "회원가입이 완료되었습니다."});
          var friendlist = "create table "+req.body.id+"Friendlist ( ID varchar(50), date varchar(50));";
          pool.getConnection(function(err,connection){
                if (err) {
                  console.log("데이터베이스 커넥션 풀 생성 실패.");
                  res.json({"code" : 100, "status" : "Error in connection database"});
                  return;
                }

                console.log('연결된 커넥션 풀 ID :  ' + connection.threadId);
                connection.on('error', function(err) {
                      res.json({"code" : 100, "status" : "Error in connection database"});
                      return;
                });
          });
        }
        else if(code==500)
        {
          //insert문 오류
          console.log("insert 문 오류!!");
          pool.getConnection(function(err,connection){
            var query="select * from user where ID='"+req.body.id+"'";
                if (err) {
                  console.log("데이터베이스 커넥션 풀 생성 실패.");
                  res.json({"code" : 100, "status" : "Error in connection database"});
                  return;
                }

                console.log('연결된 커넥션 풀 ID :  ' + connection.threadId);
                connection.query(query,function(err,rows){
                    connection.release();

                    if(rows=="")
                    {
                      console.log("알수없는 오류발생");
                      res.json({"code":100,"status":"알 수 없는 오류"});
                      return;
                    }
                    if(!err) {
                      console.log("처리된 값들 :" + rows);
                      res.json({"code":300,"status":"이미 가입된 아이디입니다."});
                        <!--json 데이터 반환함-->
                    }
                });

                connection.on('error', function(err) {
                      res.json({"code" : 100, "status" : "Error in connection database"});
                      return;
                });
          });
        }
      });
  }
});
<!-- 글쓰기 요청-->
app.post('/write',function(req,res){
  //글쓰기
//  console.log("ㅇㅇ");
  var sql = "insert into board set ?";
  var board = {
    date : new Date(),
    id : req.session.login_id,
    text : req.body.text,
    code : req.body.code,
    name : req.session.name,
    likeCnt: 0,
    replyCnt:0
  };
  console.log("글쓰기 텍스트"+req.body.text);
  console.log("코드는 :" + req.body.code);
  handleWriteDataBase(req,res,sql,board,function(code){
console.log(code);
      if(code==200)
      {
        res.json({"code":200,"status":"글 올라감."});
      }else {
        res.json({"code":500,"status":"에러"});
      }
  });
});
<!-- 댓글 조회-->
app.post('/reply',function(req,res){
  if(req.session.login=="true")
  {
    //세션에 로그인이 되어있어야 한다.
    fs.readFile('./public/ejs/reply.ejs',"utf8",function(err,data){

      pool.getConnection(function(err,connection){
        if(!err)
        {
          var board_no = req.body.board_no;
          var sql = "select * from replyzone where board_no="+board_no;//해당 게시글의 댓글정보 요청
          connection.query(sql,function(err,rows){
            if(err)
            {
              console.log(err);
              return;
            }
            if(rows.length>=1)
            {
              //결과값이 있을 경우.
              console.log("댓글확인요청");
              var replylist = new Array(); //댓글 리스트를 저장.
              for(var i=0; i <rows.length;i++)
              {
                replylist.push({
                  id:rows[i].ID,
                  name:rows[i].name,
                  date:rows[i].date,
                  text:rows[i].text
                });
              }
              var reply = {
                replycnt : rows.length,
                list : replylist
              }
              console.log(reply);
                res.send(ejs.render(data,reply));
            }
          });

        }
        else
        {

        }
      });

    });
  }
});
<!-- 댓글 달기-->
app.post('/writeReply',function(req,res){
  if(req.session.login=="true")
  {
    //로그인 상태 확인.
    var data = {
      ID : req.session.login_id,
      name : req.session.name,
      date : new Date(),
      text : req.body.text,
      likeCnt :0,
      board_no : req.body.board_no
    };
    console.log(data);
    var sql = "insert into replyzone set ?";
    handleWriteDataBase(req,res,sql,data,function(code){
      if(code==200)
      {
        sql = "update board set replyCnt= replyCnt+1 where board_no ="+req.body.board_no;
        pool.getConnection(function(err,connection){
          connection.query(sql,function(err,rows){
            if(!err)
            {
              res.json({"code":200,"status":"글 올라감."});
              console.log("증가함");
            }
            else
            {console.log("댓글증가에러");}
          });
        });
      }else {
        res.json({"code":500,"status":"에러"});
      }
    });
  }
});

<!-- 좋아요 누르기-->
app.post('/like',function(req,res){
  if(req.session.login=="true")
  {
    pool.getConnection(function(err,connection){
      var sql = "select * from likezone where ID='"+req.session.login_id+"' AND board_no="+req.body.board_no;
      connection.query(sql,function(err,rows){
        if(err)
        {
          res.json({"code":300,"status":"알 수 없는 오류"});
        }
        else {
          if(rows.length==0)
          {
            sql = "insert into likezone set ?";
            var data = {
              ID : req.session.login_id,
              board_no : req.body.board_no
            };
            handleWriteDataBase(req,res,sql,data,function(code){
              if(code==200)
              {
                sql = "update board set likeCnt=likeCnt+1 where board_no="+req.body.board_no;
                connection.query(sql,function(err,rows){
                  if(!err)
                  {
                          res.json({"code":200,"status":"좋아요 처리완료"});
                  }
                });
              }
            });
          }
          else
          {
            res.json({"code":400,"status":"좋아요 이미 누름."});
          }
        }
      });
    });
  }
});
<!-- 타임라인 -->
app.post('/timeline',function(req,res){
  console.log("타임라인요청");
  pool.getConnection(function(err,connection){
    var sql = "select * from board where id='"+req.session.login_id+"' order by board_no desc";
    console.log(sql);
    connection.query(sql,function(err,rows){
      if(!err)
      {
        fs.readFile('./public/ejs/board.ejs',"utf8",function(err,data){
          if(rows.length>=1)
          {
              var board_array = new Array();
              var myrows = rows;
              console.log(rows.length);

                for(var k=0;k<rows.length;k++)
                {
                  board_array.push({
                    board_no : rows[k].board_no,
                    img_url:"user.PNG",
                    name:rows[k].name,
                    date:rows[k].date,
                    text:rows[k].text,
                    codeground:  rows[k].code,
                    codeline: rows[k].codeline,
                    likeCnt:rows[k].likeCnt,
                    replyCnt:rows[k].replyCnt
                  });
                }

                var jsonData = {
                  board_cnt: board_array.length,
                  board:board_array
                };
                console.log("전송");
                console.log(jsonData.board_cnt);
                console.log(jsonData.board);
                res.send(ejs.render(data,jsonData));
             }
             else{

               console.log('데이타없음');
             }
        });
      }
      else
      {
        console.log("에러발생!!!!!!!!!");
        console.log(err);
      }
    });
  });
});
<!-- 게시글 보기 요청-->
app.post('/board',function(req,res){
  if(req.session.login=="true")
  {
    fs.readFile('./public/ejs/board.ejs',"utf8",function(err,data){
      if(err){
        console.log(err);
        console.log("에러")
      }else{
        var id = req.session.login_id;
        var sql = "select * from board  order by board_no desc;";
        handleReadDataBase(req,res,sql,function(rows,code){
          if(rows.length>=1)
          {
              var board_array = new Array();
              var myrows = rows;
              console.log(rows.length);

                for(var k=0;k<rows.length;k++)
                {
                  board_array.push({
                    board_no : rows[k].board_no,
                    img_url:"user.PNG",
                    name:rows[k].name,
                    date:rows[k].date,
                    text:rows[k].text,
                    codeground:  rows[k].code,
                    likeCnt:rows[k].likeCnt,
                    replyCnt:rows[k].replyCnt,
                    id:rows[k].id
                  });
                }

                var jsonData = {
                  board_cnt: board_array.length,
                  board:board_array
                };
                  console.log("전송");
                  res.send(ejs.render(data,jsonData));
             }
        });
        }
    });
  }
  else {

  }
});
<!-- 게시글 삭제 요청-->
app.post("/delete",function(req,res){
  console.log("삭제요청");
  if(req.session.login_id==req.body.id)
  {
    console.log("삭제확인");

    //작성자 본인인지 확인.
    var sql = "delete from board where id='"+req.body.id+"' AND board_no="+req.body.board_no;
    console.log(sql);
    pool.getConnection(function(err,connection){
      if(!err)
      {
        connection.query(sql,function(err,rows){
          if(!err)
          {
            res.send({code:200});
          }
          else{
            res.send({code:100});
          }
        });
      }
    });
  }
});
<!-- 게시글 스크랩 요청-->
app.post("/scrap",function(req,res){
  if(req.session.login=="true")
  {
    var sql = "insert into scrap set ?";
    pool.getConnection(function(err,connection){
      if(!err)
      {
        var data = {
          "board_id" : req.body.board_no,
          "id" : req.session.login_id
        };
        console.log("스크랩 데이타 :"+data);
        connection.query(sql,data,function(err,rows){
          if(!err)
          {
            res.send({code:200});
          }
          else{
            res.send({code:100});
          }
        });
      }
    });
  }
});
<!--스크랩 리스트 요청 -->
app.post('/scrapShow',function(req,res){
  if(req.session.login=="true")
  {
    fs.readFile('./public/ejs/board.ejs',"utf8",function(err,data){
      if(err){
        console.log(err);
        console.log("에러")
      }else{
        var id = req.session.login_id;
        var sql = "select * from board where board_no IN(select board_id from scrap where id='"+req.session.login_id+"') order by board_no desc;";
        handleReadDataBase(req,res,sql,function(rows,code){
          if(rows.length>=1)
          {
              var board_array = new Array();
              var myrows = rows;
              console.log(rows.length);

                for(var k=0;k<rows.length;k++)
                {
                  board_array.push({
                    board_no : rows[k].board_no,
                    img_url:"user.PNG",
                    name:rows[k].name,
                    date:rows[k].date,
                    text:rows[k].text,
                    codeground:  rows[k].code,
                    likeCnt:rows[k].likeCnt,
                    replyCnt:rows[k].replyCnt,
                    id:rows[k].id
                  });
                }

                var jsonData = {
                  board_cnt: board_array.length,
                  board:board_array
                };
                      console.log("스크랩전송");
                      res.send(ejs.render(data,jsonData));
             }
             else{
               console.log("스크랩 데이터없음");
             }
        });
        }
    });
  }
  else {

  }
});
<!--공지사항 보여주기 요구-->
app.post("/notice",function(req,res){
  gachonUrl = 'http://www.gachon.ac.kr/major/bbs.jsp?pageNum='+req.body.pageNum+'&pageSize=10&boardType_seq=159&approve=&secret=&answer=&branch=&searchopt=&searchword=';
  request(gachonUrl, function(error, response, html){
  	if (error) {throw error};

    var $ = cheerio.load(html);
    var $boardlist = $(".boardlist");
    var $tr = $boardlist.find("tr");
    var $a = $tr.find("a");
    var $img = $tr.find("img");
    var _size = $a.length;
    var no_Array = new Array();
    var date_Array = new Array();
    var title_Array = new Array();
    var writer_Array = new Array();
    var show_Array = new Array();
    var link_Array = new Array();
    $a.each(function(index,item){
      var href = "http://www.gachon.ac.kr/major/";
      href = href + $(item).attr("href");
      $(item).attr("href",href);
      link_Array.push(href);
      no_Array.push($(item).parent().prev().text());
      title_Array.push($(item).text());
      writer_Array.push($(item).parent().next().text());
      date_Array.push($(item).parent().next().next().next().text());
      show_Array.push($(item).parent().next().next().next().next().text());
      <!--
      구조를 뜯어 봤는데, 각각 얻고자 하는 데이터의 위치를 parent,next,prev를 이용하여 선택자를 이동하여 해당값을 가져옴
      -->
    });
    $img.each(function(index,item){
      var href = "http://www.gachon.ac.kr";
      href = href + $(item).attr("src");
      $(item).attr("src",href);
      //상대주소로 등록되어있는 이미지를 앞에 gachon을 붙여준다.
    });
    var json = {
      size : _size,
      no : no_Array,
      date : date_Array,
      title : title_Array,
      views : show_Array,
      writer : writer_Array,
      link : link_Array
    };
    fs.readFile('./public/ejs/notice.ejs',"utf8",function(err,data){

      if(!err){
        var ejsFile = ejs.render(data,json);
        res.send(ejsFile);
        //공지사항 ejs 렌더링
      }
    });

  });
});
<!-- 알람 메세지 확인-->
app.post('/alarmShow',function(req,res){
  //알람 메세지를 읽으면 테이블로 부터 해당 메세지를 이미 읽었는지, 아닌지 체크를 한다.
  var login_id = req.session.login_id;
  var alarm_id = req.body.alarm_id;
  pool.getConnection(function(err,connection){
    var sql = "select * from alarm where alarm_id="+alarm_id;
    console.log(sql);
    connection.query(sql,function(err,rows){
      if(err)
      {
        console.log(err);
      }
      else{
        var sendData = {title:rows[0].date , text:rows[0].text};
        sql = "select * from alarmlist where id='"+login_id+"' AND alarm_id='"+alarm_id+"'";
        connection.query(sql,function(err,rows){
          if(rows.length>=1)
          {
            res.send(sendData);
          }
          else{
            sql = "insert into alarmlist set ?";
            var data = {
              "alarm_id" : alarm_id,
              id : login_id
            };
            connection.query(sql,data,function(err,rows){
                if(err)
                {

                }
                else{
                  res.send(sendData);
                }
            });
          }
        });
      }
    });
  });
});
<!-- 알람 메세지 전달-->
app.post('/alarm',function(req,res){
  //알람 메세지를 읽으려고자 하는 요청
  var id =  req.session.login_id;
  pool.getConnection(function(err,connection){
      var sql = "select * from alarm ";
      var sql2 = "select * from alarmlist where id='"+id+"'";
      var alarmArray = new Array();
      connection.query(sql,function(err,rows){
        if(rows.length>=1)
        {
          for(var i=0;i<rows.length;i++)
          {
            alarmArray.push({
              alarm_id : rows[i].alarm_id,
              date : rows[i].date,
              text : rows[i].text
            });
          }
          connection.query(sql2,function(err,rows2){
            if(!err)
            {
              var gapRow = rows.length - rows2.length; //안읽은 갯수
              res.send({
                gap : gapRow,
                array : alarmArray
              });

            }

          });
        }
      });
  });
});
<!-- 메세지 처리-->
app.get('/msg',function(req,res){
  console.log("요청 메세지"+req.query.msg);
  console.log("시크릿코드 : "+req.query.secret);
  if(req.query.secret=="aAbBcCdDeEfFgGhH")
  {
    //혹시나 get방식으로 /msg? ......를 통해 msg를 다른 곳에서 임의로 접근하려고하면
    //이상한 데이터가 들어올 수 도 있다. 그걸 방지하기위해 시크릿 코드를 지정해놓음.
    pool.getConnection(function(err,connection){
      var sql = "insert into alarm set ?";
      var dataSet = {
        date : new Date().toLocaleString(),
        text : req.query.msg
      };
      connection.query(sql,dataSet,function(err,rows){
        if(!err)
        {
          console.log("삽입 성공");
          res.send("받음");
        }
        else{
          console.log("메세지 삽입에러");
          res.send("실패");
        }
      });
    });

  }
});
app.listen(65017, function () {
  console.log('Computer Science Network 서버가 열렸습니다.');
});
function sendErrorPage(errorMessage,res)
{
  console.log("에러메세지를 전달합니다. :"+errorMessage);
  res.render();
}
  function generateAuthorCode()
  {
    return Math.random();
  }


  require('./webSocket')(app); //전체 채팅방 처리.
