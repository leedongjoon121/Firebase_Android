var io = require('socket.io').listen(8001);


module.exports= function(){
  io.sockets.on('connection', function (socket){
      var room_id;
      socket.on('joinRoom',function(data){
          room_id = data;
          socket.join("mainroom"); //룸입장
      });
      socket.on('leaveRoom',function(){
          socket.leave("mainroom");//룸퇴장
      });
      socket.on('sendMsg',function(data){
        data.date = new Date().toLocaleString(); //메세지 온거에다가 전송날짜를 포함시킴.
          io.sockets.in("mainroom").emit('msgAlert',data);
      });
      socket.on('disconnect', function(){
        socket.leave("mainroom");//룸퇴장
      });
  });
};
